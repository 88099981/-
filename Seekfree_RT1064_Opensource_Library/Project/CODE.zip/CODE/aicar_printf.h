#ifndef _aicar_printf_h
#define _aicar_printf_h
#include "common.h"

void aicar_adc_printf();
void aicar_servopid_printf();
void aicar_motorpid_printf();
void aicar_chasu_printf();
void aicar_huandao_printf();
void aicar_camerapid_printf();
void aicar_20602_printf();

void print_main();
void print_debug();
void print_parameter();
void print_gogogo();
void print_ourteam();

#endif

