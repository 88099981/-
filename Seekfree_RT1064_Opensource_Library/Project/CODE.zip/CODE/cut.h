#ifndef __CUT_H__
#define __CUT_H__

#include "headfile.h"
#include "common.h"
#include "camera.h"
//extern void get_cut_array();		//��ʼ������ 
//extern void cut_image_to_img();
extern void cut_image_to_img2(void);
extern void mv_image_to_img2(void);

//extern uint8 img_cut_H[IMG_H]; 
//extern uint8 img_cut_W[IMG_W];

#endif
