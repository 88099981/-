#ifndef _FD_FEATUREDATA_H_
#define _FD_FEATUREDATA_H_

#include "headfile.h"

extern uint8 Block_A[];

#endif