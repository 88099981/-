#ifndef _aicar_gogogo_h
#define _aicar_gogogo_h
#include"common.h"

//����
void aicar_gogogo(void);

#endif