#ifndef _aicar_chasu_h
#define _aicar_chasu_h

void aicar_chasu();
void aicar_n_chasu();

#endif