#ifndef __OSTU_H__
#define __OSTU_H__

#include "headfile.h"
#include "common.h"
//#define White 255
//#define Black 0

extern uint8 ostu_thres;

extern uint8 get_ostu_thres();
extern void binary_img();
#endif
