#ifndef _FD_FEATUREDATA_H_
#define _FD_FEATUREDATA_H_

#include "headfile.h"

extern uint8 Block_A[]; //��СΪ1000�İ׿�
extern uint8 Block_B[]; //��СΪ1000�ĺڿ�
extern uint8 Block_C[];

#endif